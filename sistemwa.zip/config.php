<?php
error_reporting(~E_NOTICE);

$conn = mysqli_connect('localhost','root','','db_sistemwa');
?>

