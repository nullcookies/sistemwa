<h1>About Program</h1>
<p>Program Auto Send Massage Via Whatsapp yang memiliki sistem scheduling<br>
    untuk memudahkan pengiriman pesan
    dan juga menghindari blokir akun atau spam<br>
    <b>&copy;Copyright 2019 All Right Reserved</b>
</p>
<hr>